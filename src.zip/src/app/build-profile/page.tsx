// src/app/build-profile/page.tsx
import ProfileWizard from '@/components/therapistAccount/build-profile/ProfileWizard'

export default function BuildProfilePage() {
  return <ProfileWizard />
}

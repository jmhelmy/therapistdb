import specialtiesRaw from '@/data/specialties.csv'
import locationsRaw from '@/data/locations.csv'

type Specialty = {
  id: string
  name: string
  slug: string
}

type Location = {
  id: string
  city: string
  citySlug: string
  neighborhood?: string
  neighborhoodSlug?: string
  zipCodes: string[] | string // depending on how it's parsed
}

// Ensure zipCodes is parsed correctly (CSV parsers might give you strings)
const locations: Location[] = locationsRaw.map((loc) => ({
  ...loc,
  zipCodes: Array.isArray(loc.zipCodes)
    ? loc.zipCodes
    : JSON.parse(loc.zipCodes || '[]')
}))

const specialties: Specialty[] = specialtiesRaw

export function getSpecialtyBySlug(slug: string): Specialty | undefined {
  return specialties.find((s) => s.slug === slug)
}

export function getLocationData(
  citySlug: string,
  neighborhoodSlug?: string
): Location | undefined {
  return locations.find(
    (loc) =>
      loc.citySlug === citySlug &&
      (!neighborhoodSlug || loc.neighborhoodSlug === neighborhoodSlug)
  )
}

export function resolveZipToLocation(zip: string): Location | undefined {
  return locations.find((loc) =>
    Array.isArray(loc.zipCodes)
      ? loc.zipCodes.includes(zip)
      : false
  )
}

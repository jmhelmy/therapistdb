export const specialties = [
  { id: '1', name: 'Christian Therapy', slug: 'christian' },
  { id: '2', name: 'Cognitive Behavioral Therapy', slug: 'cbt' },
  { id: '3', name: 'EMDR Therapy', slug: 'emdr' },
  { id: '4', name: 'DBT Therapy', slug: 'dbt' },
  { id: '5', name: 'Trauma Therapy', slug: 'trauma' },
  { id: '6', name: 'Family Therapy', slug: 'family' },
  { id: '7', name: 'Child Therapy', slug: 'child' },
  { id: '8', name: 'Grief Counseling', slug: 'grief' },
  { id: '9', name: 'Couples Counseling', slug: 'couples' },
  { id: '10', name: 'Christian Counseling', slug: 'christian-counseling' }
]
